package oit.is.z2946.kaizi.janken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JankenApplicationTests {

	@Test
	void contextLoads() {
	}

}
